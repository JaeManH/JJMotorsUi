function MainEventBanner() {
  return <div>메인 이벤트 배너</div>;
}
